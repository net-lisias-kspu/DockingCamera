﻿Docking-camera itself, which can be integrated to any part (MM patch enclosed for the docking port modules). 
It looks ahead by the vertical axis of the vessel's and displays a minimum of necessary info for the docking 
maneuver - namely, range, speed, angle, alignment and when the correct trajectory occured - time prior to 
docking with the mark that such trajectory will lead our vessel to dock without additional actions (small 
lamp will become green and will show time to docking). camera window has three size presets. It also has 
three viewing modes: color, Black and white and infrared. Powered zoom function. Also, there is a button to 
remove flight data from the screen. Furthermore, effect of television interference can be added. The range 
of the camera,parameters of night vision (RSMA) and presence of noise - can be configured through CFG. Camera 
requires a target to operate.

In addition the ugly external camera enclosed. It can show videostream only and also has three modes of vision 
and is able to rotate on two axes. For cameras, installed under the belly of the aircraft (which gets inverted 
upside down) there is the mode of rotation of the image. In the CFG of the partcamera some meshes could be 
configured for use with other camera model.

All cameras have a title with its number, and also can work a few pieces at a time. Docking camera reporting its
target on its window title.

There is an experiment on part camera - a try to reproduce a surveilance (spy) activity. You need to be at a 
distance less than 1000 m near any targetable thingie, catch it on camera's screen and targeted. press "⦿"
button. 
A ray will be shot. If all requirements have met and there are no obstacle on ray's path - you'll should get 
experiment results, if something wrong - you just spend one bullet.  Experiments is limited by bullets (4 yellow
balls around cam, dissapearing one by one each time). I thought it will be interesting if contracts.

Camera has 3 presets of shaders (noisy TV 1960th style, TV 1980th style  and standart (color, b/w and
nightvision).  Available via button, appearing when blizzy toolbar is installed. 

Also, by toolbar button you could find info about nearby cameras installed on other vessels in transmission
range.  If camera has been activated on some vessel, but you drive other one - a new window from distant camera
will appear when distance from first one will become less than 2500 (or 10k (customizable)). 

If you want you can use "look at me" mode by activating it on distant camera. "Targetcam"  and "follow me" modes

on your active vessel (set camera position using scrollers).

The cameras can transmit the videostream to nearby vessels, but only at a distance of up to 2 500 meters. You 
can change this unload range via toolbar button.